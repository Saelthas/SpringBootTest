package com.tsb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
