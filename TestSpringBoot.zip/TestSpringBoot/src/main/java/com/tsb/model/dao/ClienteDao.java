package com.tsb.model.dao;

import org.springframework.data.repository.CrudRepository;

import com.tsb.model.entity.Cliente;

public interface ClienteDao extends CrudRepository<Cliente,Integer>{

}
