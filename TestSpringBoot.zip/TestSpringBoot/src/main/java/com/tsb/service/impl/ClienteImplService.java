package com.tsb.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tsb.model.dao.ClienteDao;
import com.tsb.model.dto.ClienteDto;
import com.tsb.model.entity.Cliente;
import com.tsb.service.ICliente;

import ch.qos.logback.core.net.server.Client;

@Service
public class ClienteImplService implements ICliente{
	@Autowired
	private ClienteDao clienteDao;
	@Transactional
	@Override
	public Cliente save(ClienteDto clienteDto) {
		// TODO Auto-generated method stub
		Cliente cliente= Cliente.builder()
				.idCliente(clienteDto.getIdCliente())
				.nombre(clienteDto.getNombre())
				.apellido(clienteDto.getApellido())
                .correo(clienteDto.getCorreo())
                .fechaRegistro(clienteDto.getFechaRegistro())
				.build();
		return clienteDao.save(cliente);
	}
	@Transactional(readOnly = true)
	@Override
	public ClienteDto findById(Integer idCliente) {
		// TODO Auto-generated method stub
		Map<String, Object> response = new HashMap<>();	
		Cliente cliente= clienteDao.findById(idCliente).orElse(null);
		ClienteDto clienteDto= ClienteDto.builder()
				.idCliente(cliente.getIdCliente())
				.nombre(cliente.getNombre())
				.apellido(cliente.getApellido())
                .correo(cliente.getCorreo())
                .fechaRegistro(cliente.getFechaRegistro())
				.build();
		return clienteDto;
		 
	}
	@Transactional
	@Override
	public void delete(Integer idCliente) {
		// TODO Auto-generated method stub
		
		Cliente cliente= clienteDao.findById(idCliente).orElse(null);
		clienteDao.delete(cliente);
		
	}

	
}
