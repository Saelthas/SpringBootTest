package com.tsb.service;

import com.tsb.model.dto.ClienteDto;
import com.tsb.model.entity.Cliente;

public interface ICliente {

	Cliente save(ClienteDto cliente);
	ClienteDto findById(Integer idCliente);
	void delete(Integer idCliente);
}
